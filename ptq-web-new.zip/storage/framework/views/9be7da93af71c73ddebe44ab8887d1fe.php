<div class="flex items-center gap-2">
    <img src="<?php echo e(asset('images/logo-ptq.svg')); ?>" alt="Logo PTQ" class="h-8 w-auto" />
    <span class="font-bold text-xl tracking-tight text-gray-900 dark:text-white">UKM PTQ</span>
</div><?php /**PATH C:\laragon\www\ptq-web-new\resources\views/vendor/filament/components/brand.blade.php ENDPATH**/ ?>