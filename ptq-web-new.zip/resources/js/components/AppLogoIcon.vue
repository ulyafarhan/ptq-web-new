<template>
    <img src="/images/logo.png" alt="Logo" class="h-9 w-9 object-contain" />
</template>