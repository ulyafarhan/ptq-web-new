<template>
    <div class="flex items-center gap-2">
        <img src="/images/logo.png" alt="Logo" class="h-8 w-auto" />
        <span class="font-bold text-slate-900 text-lg">UKM PTQ</span>
    </div>
</template>