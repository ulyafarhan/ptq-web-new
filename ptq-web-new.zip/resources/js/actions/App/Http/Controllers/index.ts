import Settings from './Settings'
const Controllers = {
    Settings: Object.assign(Settings, Settings),
}

export default Controllers